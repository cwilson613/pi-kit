//! omegon-demo — a small config-file tool for the Omegon tutorial.
//!
//! Reads a TOML configuration file, validates it, and produces
//! formatted output. Designed to have enough modules for a meaningful
//! cleave demonstration.

pub mod config;
pub mod validate;
pub mod format;

pub use config::Config;
pub use validate::validate;
pub use format::format_output;
