---
id: output-formatting
title: Output formatting — configurable display styles
status: exploring
parent:
tags: [formatting, ux]
open_questions:
  - Should we support ANSI color output? If so, how do we detect terminal capability?
---

# Output formatting — configurable display styles

## Overview

The current `format_output` function produces a fixed box-drawing format. Users may want different output styles: plain text, JSON, YAML, or colored terminal output.

## Research

## Decisions

## Open Questions

- Should we support ANSI color output? If so, how do we detect terminal capability?
