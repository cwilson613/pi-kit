// sprint-board — task management logic
// NOTE: This file has 4 known bugs documented in the design tree.
// See ai/docs/ for the architectural decisions and fix specs.

// ─── Data ────────────────────────────────────────────────────────────────────

const STORAGE_KEY = 'sprint-board-tasks';

const DEFAULT_TASKS = [
  { id: 1, title: 'Set up project scaffolding',  status: 'done',        priority: 'high'   },
  { id: 2, title: 'Design database schema',       status: 'done',        priority: 'high'   },
  { id: 3, title: 'Build authentication flow',    status: 'in-progress', priority: 'high'   },
  { id: 4, title: 'Write API integration tests',  status: 'in-progress', priority: 'medium' },
  { id: 5, title: 'Add input validation',         status: 'backlog',     priority: 'medium' },
  { id: 6, title: 'Implement search endpoint',    status: 'backlog',     priority: 'low'    },
];

let tasks = loadTasks();
let nextId = Math.max(...tasks.map(t => t.id), 0) + 1;

function loadTasks() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [...DEFAULT_TASKS];
  } catch {
    return [...DEFAULT_TASKS];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// ─── Bug #1 — Wrong selector doubles the task count ──────────────────────────
// The selector '.task' matches both .task-card AND the .task-title span inside
// each card, so every task is counted twice.
// Fix: change '.task' to '.task-card'
function getTotalCount() {
  return document.querySelectorAll('.task').length;
}

// ─── Bug #2 — Case mismatch hides completed tasks ────────────────────────────
// Tasks are stored with status 'done' (lowercase) but the filter checks
// against 'Done' (title case). The Done column is always empty as a result.
// Fix: change 'Done' to 'done', 'In Progress' to 'in-progress', 'Backlog' to 'backlog'
function getTasksByStatus(status) {
  const STATUS_MAP = { 'Backlog': 'Backlog', 'In Progress': 'In Progress', 'Done': 'Done' };
  return tasks.filter(t => t.status === STATUS_MAP[status]);
}

// ─── Bug #3 — Missing preventDefault causes page reload on add ───────────────
// The form submit handler never calls event.preventDefault(), so the browser
// performs a full page reload when the user submits the form. The task is
// added momentarily but then lost as the page reloads.
// Fix: add event.preventDefault() as the first line of handleAddTask
function handleAddTask(event) {
  const input = document.getElementById('new-task-input');
  const title = input.value.trim();
  if (!title) return;
  addTask(title);
  input.value = '';
  input.focus();
}

// ─── Bug #4 — Mutations never persisted to localStorage ──────────────────────
// addTask() and updateTaskStatus() both modify the in-memory `tasks` array
// and call renderBoard(), but neither calls saveTasks(). All changes are
// lost when the page is refreshed.
// Fix: call saveTasks() at the end of addTask() and updateTaskStatus()
function addTask(title, priority = 'medium') {
  const task = { id: nextId++, title, status: 'backlog', priority };
  tasks.push(task);
  renderBoard();
  // BUG: missing saveTasks()
}

function updateTaskStatus(id, newStatus) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  task.status = newStatus;
  renderBoard();
  // BUG: missing saveTasks()
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasks(); // correctly persists
  renderBoard();
}

// ─── Rendering ───────────────────────────────────────────────────────────────

const COLUMNS = [
  { id: 'backlog',     label: 'Backlog',     color: '#4a5568' },
  { id: 'in-progress', label: 'In Progress', color: '#2b6cb0' },
  { id: 'done',        label: 'Done',        color: '#276749' },
];

function renderBoard() {
  const board = document.getElementById('board');
  board.innerHTML = '';

  COLUMNS.forEach(col => {
    const colTasks = getTasksByStatus(col.label);
    const colEl = document.createElement('div');
    colEl.className = 'column';
    colEl.innerHTML = `
      <div class="column-header" style="border-top: 3px solid ${col.color}">
        <span class="column-title">${col.label}</span>
        <span class="column-count">${colTasks.length}</span>
      </div>
      <div class="task-list" id="col-${col.id}">
        ${colTasks.map(task => renderTask(task)).join('')}
      </div>
    `;
    board.appendChild(colEl);
  });

  document.getElementById('total-count').textContent = getTotalCount();
}

function renderTask(task) {
  const priorityColors = { high: '#fc8181', medium: '#f6ad55', low: '#68d391' };
  const nextStatuses = {
    'backlog': [{ label: '→ Start', status: 'in-progress' }],
    'in-progress': [{ label: '→ Done', status: 'done' }, { label: '← Back', status: 'backlog' }],
    'done': [{ label: '← Reopen', status: 'backlog' }],
  };
  const actions = (nextStatuses[task.status] || [])
    .map(a => `<button class="action-btn" onclick="updateTaskStatus(${task.id}, '${a.status}')">${a.label}</button>`)
    .join('');

  return `
    <div class="task-card" data-id="${task.id}">
      <div class="task-header">
        <span class="task-title">${escapeHtml(task.title)}</span>
        <span class="priority-dot" style="background:${priorityColors[task.priority]}" title="${task.priority}"></span>
      </div>
      <div class="task-actions">
        ${actions}
        <button class="delete-btn" onclick="deleteTask(${task.id})">✕</button>
      </div>
    </div>
  `;
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ─── Init ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  renderBoard();

  const form = document.getElementById('add-task-form');
  form.addEventListener('submit', handleAddTask);
});
