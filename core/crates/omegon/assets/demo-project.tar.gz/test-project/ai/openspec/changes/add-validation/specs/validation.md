# Validation Rules

## Scenario: Version must be valid semver

Given a config with version "not-a-version"
When validate() is called
Then it returns an error containing "invalid semver"

## Scenario: Port must be in user range

Given a config with port 80
When validate() is called
Then it returns an error containing "port must be between 1024 and 65535"

Given a config with port 8080
When validate() is called
Then it passes port validation

## Scenario: Feature names must be valid identifiers

Given a config with features ["logging", "bad feature!"]
When validate() is called
Then it returns an error containing "invalid feature name"

Given a config with features ["logging", "health-check"]
When validate() is called
Then it passes feature validation

## Scenario: Name must be a valid identifier

Given a config with name "my service"
When validate() is called
Then it returns an error containing "name must be a valid identifier"

Given a config with name "my-service"
When validate() is called
Then it passes name validation
