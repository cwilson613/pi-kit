# omegon-demo

A small Rust CLI tool for reading, validating, and displaying TOML configuration files.

## Project Structure

- `src/main.rs` — CLI entry point
- `src/lib.rs` — public API (Config, validate, format_output)
- `src/config.rs` — TOML parsing
- `src/validate.rs` — validation rules
- `src/format.rs` — output formatting
- `example.toml` — sample configuration file

## Current State

The tool works for basic configs but validation is minimal. The `add-validation` OpenSpec change has specs ready for implementation — it needs semver checking, port range validation, and feature name validation.

## Conventions

- Tests live in each module's `#[cfg(test)]` block
- Design docs in `docs/`
- OpenSpec changes in `openspec/changes/`
