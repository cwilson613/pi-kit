---
id: add-validation
title: Add comprehensive input validation
status: decided
parent:
tags: [validation, quality]
openspec_change: add-validation
---

# Add comprehensive input validation

## Overview

The current validation is minimal — only checks for empty name and zero port. We need comprehensive validation: semver format checking for version strings, feature name validation against an allowed list, and port range validation (1024-65535 for non-root users).

## Decisions

### Validate all fields with specific rules
**Status:** decided
**Rationale:** Each config field should have clear validation rules. Version must be valid semver. Port must be in the user-accessible range (1024-65535). Feature names must be alphanumeric with hyphens only. Name must be a valid identifier (no spaces, no special chars beyond hyphens).

## Open Questions
