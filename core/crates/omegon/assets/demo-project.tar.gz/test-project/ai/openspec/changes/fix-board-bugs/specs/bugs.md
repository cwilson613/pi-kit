# Spec: Fix Sprint Board Bugs

## Requirement: Task count is accurate

### Scenario: Header shows correct total
Given the board has loaded with 6 default tasks
When the page renders
Then the total count in the header shows 6, not 12

### Scenario: Column counts match their tasks
Given 2 tasks have status 'done', 2 have 'in-progress', 2 have 'backlog'
When the board renders
Then the Backlog column count shows 2
And the In Progress column count shows 2
And the Done column count shows 2

---

## Requirement: Done column displays completed tasks

### Scenario: Default done tasks appear in Done column
Given the default tasks include IDs 1 and 2 with status 'done'
When the board renders
Then the Done column contains exactly 2 task cards
And those cards show 'Set up project scaffolding' and 'Design database schema'

### Scenario: Moving a task to done makes it appear in Done column
Given a task is in the In Progress column
When the user clicks the '→ Done' button on that task
Then the task card moves from In Progress to the Done column

---

## Requirement: Add task form works without page reload

### Scenario: Adding a task stays on the same page
Given the user types 'Write unit tests' in the input field
When the user clicks Add Task
Then a new task card appears in the Backlog column
And the page does not reload
And the input field is cleared

### Scenario: Empty input is rejected
Given the input field is empty
When the user clicks Add Task
Then no task is added
And the board is unchanged

---

## Requirement: Task changes persist across refresh

### Scenario: New task survives page refresh
Given the user adds a task 'Deploy to staging'
When the user refreshes the page
Then the task 'Deploy to staging' is still visible in the Backlog column

### Scenario: Status change survives page refresh
Given the user moves 'Add input validation' from Backlog to In Progress
When the user refreshes the page
Then 'Add input validation' appears in the In Progress column, not Backlog
