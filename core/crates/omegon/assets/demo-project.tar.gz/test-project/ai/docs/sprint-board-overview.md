---
id: sprint-board-overview
title: Sprint board — architecture and technology decisions
status: decided
tags: [architecture, web-ui, javascript]
open_questions: []
---

# Sprint board — architecture and technology decisions

## Overview

A single-page sprint board for tracking tasks across Backlog, In Progress, and Done columns. Built as a pure HTML/CSS/JavaScript application with no framework dependencies and localStorage for persistence.

## Decisions

### Pure HTML/CSS/JS — no framework
**Status:** decided
**Rationale:** The scope is small enough that a framework adds more complexity than it removes. A single index.html with src/board.js and src/styles.css is portable, requires no build step, and opens directly in any browser.

### localStorage for persistence
**Status:** decided
**Rationale:** No backend is needed for a personal sprint board. localStorage provides session-persistent state without a server. Data is serialized as JSON on write, deserialized on read. All mutations must call saveTasks() immediately — no deferred writes.

### Status values are lowercase strings
**Status:** decided
**Rationale:** Task status values are stored as lowercase strings: 'backlog', 'in-progress', 'done'. Display labels are separate. This prevents the case-mismatch class of bug in comparisons and filters.
