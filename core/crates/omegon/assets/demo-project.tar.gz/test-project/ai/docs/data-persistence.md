---
id: data-persistence
title: Data persistence — localStorage save on every mutation
status: decided
tags: [bug, persistence, javascript]
openspec_change: fix-board-bugs
open_questions: []
---

# Data persistence — localStorage save on every mutation

## Overview

All mutations to the tasks array must immediately persist to localStorage by calling saveTasks(). Failing to do so means changes survive only until the next page refresh.

## Decisions

### Eager persistence — call saveTasks() after every mutation
**Status:** decided
**Rationale:** localStorage writes are synchronous and cheap for small arrays (~6-50 tasks). The pattern is: mutate the array → call saveTasks() → call renderBoard(). Every function that modifies tasks must follow this pattern without exception. deleteTask() already does this correctly. addTask() and updateTaskStatus() do not.

## Known Bug

`addTask()` and `updateTaskStatus()` in src/board.js both modify the tasks array and call `renderBoard()` but never call `saveTasks()`. The board appears to work during a session but all new tasks and status changes vanish on page refresh. Only the default 6 tasks are ever persisted.
