# Add comprehensive input validation

## Intent

Add thorough validation to all configuration fields: semver version checking, port range validation, and feature name validation. Each rule should have clear error messages and be independently testable.

## Scope

- `src/validate.rs` — add validation rules for version, port range, feature names, and name format
- `src/config.rs` — add helper methods if needed for parsing sub-fields
- Tests for each validation rule
