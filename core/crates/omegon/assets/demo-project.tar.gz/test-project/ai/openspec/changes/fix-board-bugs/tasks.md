# Tasks: Fix Sprint Board Bugs

## 1. Fix task count selector
<!-- specs: bugs -->
- [ ] Change `getTotalCount()` selector from `'.task'` to `'.task-card'`
- [ ] Verify header shows 6 (not 12) with default data

## 2. Fix column status filter
<!-- specs: bugs -->
- [ ] Fix `getTasksByStatus()` to compare against column.id (lowercase) not column.label
- [ ] Remove the STATUS_MAP indirection — pass the lowercase status string directly
- [ ] Verify Done column shows tasks 1 and 2 from default data

## 3. Fix form submission
<!-- specs: bugs -->
- [ ] Add `event.preventDefault()` as first line of `handleAddTask(event)`
- [ ] Verify Add Task button adds a card without reloading the page

## 4. Fix localStorage persistence
<!-- specs: bugs -->
- [ ] Add `saveTasks()` call at end of `addTask()` after `renderBoard()`
- [ ] Add `saveTasks()` call at end of `updateTaskStatus()` after `renderBoard()`
- [ ] Verify added tasks survive page refresh
- [ ] Verify status changes survive page refresh
