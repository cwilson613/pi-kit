# Tasks

## Design

- [x] Define validation rules for each config field

## Implementation

- [ ] Add semver validation for version field
- [ ] Add port range validation (1024-65535)
- [ ] Add feature name validation (alphanumeric + hyphens only)
- [ ] Add name format validation (valid identifier, no spaces)
- [ ] Add tests for each validation rule
