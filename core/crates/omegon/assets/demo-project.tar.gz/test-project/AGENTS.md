# Sprint Board — Agent Directives

This is a mid-development sprint board web app with known bugs. You are working
on a pure HTML/CSS/JavaScript project — no build step, no framework.

## Project Context

- `index.html` — the app entry point
- `src/board.js` — all task logic; 4 documented bugs
- `src/styles.css` — styling

## Working Conventions

- Task status values are always lowercase: 'backlog', 'in-progress', 'done'
- All mutations must call saveTasks() before renderBoard()
- Do not introduce new dependencies or frameworks
- Do not modify index.html or styles.css unless explicitly asked

## Known Bugs

All four bugs are documented in `src/board.js` with `// BUG:` comments
and in the design tree (`ai/docs/`). Fix only the documented bugs — do not
refactor or expand scope.

## Reference Implementation

`deleteTask()` is the only correctly-implemented mutation. Use it as the
pattern for how addTask() and updateTaskStatus() should be written.
