//! Configuration validation rules.

use crate::Config;

/// Validate a configuration. Returns Ok(()) if valid, or a list of errors.
pub fn validate(config: &Config) -> Result<(), Vec<String>> {
    let mut errors = Vec::new();

    if config.name.is_empty() {
        errors.push("name must not be empty".into());
    }

    if config.name.len() > 64 {
        errors.push("name must be 64 characters or fewer".into());
    }

    if config.port == 0 {
        errors.push("port must be non-zero".into());
    }

    // TODO: validate version format (semver)
    // TODO: validate feature names against allowed list

    if errors.is_empty() {
        Ok(())
    } else {
        Err(errors)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_config_passes() {
        let config = Config {
            name: "test".into(),
            version: "1.0.0".into(),
            port: 8080,
            features: vec![],
        };
        assert!(validate(&config).is_ok());
    }

    #[test]
    fn empty_name_fails() {
        let config = Config {
            name: "".into(),
            version: "1.0.0".into(),
            port: 8080,
            features: vec![],
        };
        assert!(validate(&config).is_err());
    }

    #[test]
    fn zero_port_fails() {
        let config = Config {
            name: "test".into(),
            version: "1.0.0".into(),
            port: 0,
            features: vec![],
        };
        let errors = validate(&config).unwrap_err();
        assert!(errors.iter().any(|e| e.contains("port")));
    }
}
