//! Output formatting for configuration display.

use crate::Config;

/// Format a configuration for human-readable display.
pub fn format_output(config: &Config) -> String {
    let mut out = String::new();
    out.push_str(&format!("╭─ {} v{} ─╮\n", config.name, config.version));
    out.push_str(&format!("│ Port: {} │\n", config.port));
    if !config.features.is_empty() {
        out.push_str(&format!("│ Features: {} │\n", config.features.join(", ")));
    }
    out.push_str("╰────────────────╯");
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn format_includes_name() {
        let config = Config {
            name: "myapp".into(),
            version: "2.0".into(),
            port: 3000,
            features: vec!["logging".into()],
        };
        let output = format_output(&config);
        assert!(output.contains("myapp"));
        assert!(output.contains("3000"));
        assert!(output.contains("logging"));
    }
}
