---
id: task-count-display
title: Task count display — accurate totals in header and columns
status: decided
tags: [bug, display, javascript]
openspec_change: fix-board-bugs
open_questions: []
---

# Task count display — accurate totals in header and columns

## Overview

The header shows a total task count, and each column header shows the count of tasks in that column. Both must reflect the actual data — not DOM element counts.

## Decisions

### Count from data, not from DOM
**Status:** decided
**Rationale:** getTotalCount() currently uses document.querySelectorAll('.task').length. The selector '.task' matches both the .task-card div AND the .task-title span inside it (which also has class 'task'), doubling the count. The correct selector is '.task-card', which only matches the outer card element. Alternatively, count from the tasks array directly: tasks.length.

## Known Bug

`getTotalCount()` in src/board.js uses the wrong CSS selector '.task' which matches nested elements and doubles every count. The header shows 12 when there are 6 tasks.
