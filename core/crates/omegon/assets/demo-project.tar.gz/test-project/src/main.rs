use omegon_demo::{Config, validate, format_output};
use std::process;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    
    if args.is_empty() {
        eprintln!("Usage: omegon-demo <config-file>");
        eprintln!("       omegon-demo --validate <config-file>");
        process::exit(1);
    }

    let validate_only = args.first().map(|a| a == "--validate").unwrap_or(false);
    let file = if validate_only { &args[1] } else { &args[0] };

    let config = match Config::from_file(file) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("Error: {e}");
            process::exit(1);
        }
    };

    if validate_only {
        match validate(&config) {
            Ok(()) => println!("✓ Configuration is valid"),
            Err(errors) => {
                eprintln!("Configuration errors:");
                for e in &errors {
                    eprintln!("  • {e}");
                }
                process::exit(1);
            }
        }
    } else {
        println!("{}", format_output(&config));
    }
}
