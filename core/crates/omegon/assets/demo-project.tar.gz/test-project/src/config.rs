//! Configuration parsing from TOML files.

use std::path::Path;

/// Application configuration parsed from a TOML file.
#[derive(Debug, Clone)]
pub struct Config {
    pub name: String,
    pub version: String,
    pub port: u16,
    pub features: Vec<String>,
}

impl Config {
    /// Load configuration from a TOML file.
    pub fn from_file(path: &str) -> Result<Self, String> {
        let content = std::fs::read_to_string(Path::new(path))
            .map_err(|e| format!("cannot read {path}: {e}"))?;
        Self::parse(&content)
    }

    /// Parse configuration from a TOML string.
    pub fn parse(content: &str) -> Result<Self, String> {
        let mut name = String::new();
        let mut version = String::new();
        let mut port = 8080u16;
        let mut features = Vec::new();

        for line in content.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            if let Some((key, value)) = line.split_once('=') {
                let key = key.trim();
                let value = value.trim().trim_matches('"');
                match key {
                    "name" => name = value.to_string(),
                    "version" => version = value.to_string(),
                    "port" => port = value.parse().map_err(|_| format!("invalid port: {value}"))?,
                    "features" => {
                        // Simple comma-separated list
                        features = value.split(',').map(|s| s.trim().to_string()).collect();
                    }
                    _ => {} // ignore unknown keys
                }
            }
        }

        if name.is_empty() {
            return Err("missing required field: name".into());
        }

        Ok(Self { name, version, port, features })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_valid_config() {
        let config = Config::parse("name = \"demo\"\nversion = \"1.0\"\nport = 3000").unwrap();
        assert_eq!(config.name, "demo");
        assert_eq!(config.port, 3000);
    }

    #[test]
    fn parse_missing_name() {
        let result = Config::parse("version = \"1.0\"");
        assert!(result.is_err());
    }

    #[test]
    fn parse_with_features() {
        let config = Config::parse("name = \"app\"\nfeatures = logging, metrics").unwrap();
        assert_eq!(config.features, vec!["logging", "metrics"]);
    }
}
