---
id: form-submission
title: Form submission — prevent default browser reload on add task
status: decided
tags: [bug, forms, javascript]
openspec_change: fix-board-bugs
open_questions: []
---

# Form submission — prevent default browser reload on add task

## Overview

The add-task form uses `<form>` with a submit event. The submit handler must call `event.preventDefault()` to stop the browser from reloading the page.

## Decisions

### Always call preventDefault on form submit
**Status:** decided
**Rationale:** Without preventDefault(), clicking "Add Task" submits the form using the browser's default GET/POST behavior, which causes a full page reload. The task is added to the in-memory array for a split second, then lost when the page reloads. The fix is one line: `event.preventDefault()` as the first statement in handleAddTask().

## Known Bug

`handleAddTask(event)` in src/board.js never calls `event.preventDefault()`. Clicking the "Add Task" button causes the page to reload, appearing to do nothing. Any task typed is lost immediately.
