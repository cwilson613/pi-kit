---
id: column-routing
title: Column routing — task status to column mapping
status: decided
tags: [bug, display, javascript]
openspec_change: fix-board-bugs
open_questions: []
---

# Column routing — task status to column mapping

## Overview

Tasks are assigned to columns by their `status` field. The filter must use the same case as the stored values. Mismatch causes tasks to silently disappear.

## Decisions

### Status comparison must use stored lowercase values
**Status:** decided
**Rationale:** Tasks are stored with status 'backlog', 'in-progress', 'done' (all lowercase). The COLUMNS array uses these same values as IDs. getTasksByStatus() must compare against these exact values. The current STATUS_MAP translates 'Done' → 'Done', 'In Progress' → 'In Progress', etc., but tasks are never stored with title-case status values, so all filters return empty arrays.

**Fix:** Replace the STATUS_MAP lookup with direct comparison using column.id (the lowercase value) rather than column.label (the display string).

## Known Bug

The Done column is always empty because `getTasksByStatus('Done')` filters for `task.status === 'Done'`, but tasks are stored with `status: 'done'`. Tasks 1 and 2 in the default data are done but never appear.
