# Sprint Board

A simple browser-based sprint board for tracking tasks across Backlog, In Progress, and Done.

## The Problem

This project is mid-development and has **4 known bugs** that need fixing:

1. **Wrong task count** — the total shows 12 when there are 6 tasks
2. **Done column always empty** — completed tasks don't appear there
3. **Add Task reloads the page** — nothing gets added
4. **Changes lost on refresh** — no localStorage persistence

Open `index.html` in your browser to see the broken state.

## Structure

```
index.html          — the sprint board app
src/board.js        — task logic (4 bugs documented inline)
src/styles.css      — styling
ai/docs/            — design decisions for each bug
ai/openspec/        — fix-board-bugs: specs + 4-branch cleave plan
ai/memory/          — pre-loaded facts about the project
```

## Fixing It

The `fix-board-bugs` OpenSpec change has Given/When/Then specs and a
prepared 4-task plan. Run the cleave to fix all four bugs in parallel:

```
/cleave fix-board-bugs
```

After the cleave completes, open `index.html` — the board works.

## Design Tree

Six design nodes document the architecture decisions and known issues:

- `sprint-board-overview` — tech stack decisions (decided)
- `task-count-display` — count accuracy (decided, bound to spec)
- `column-routing` — status-to-column mapping (decided, bound to spec)
- `form-submission` — preventDefault requirement (decided, bound to spec)
- `data-persistence` — localStorage mutation pattern (decided, bound to spec)
- `search-filter` — filter UX (exploring, has open question)
