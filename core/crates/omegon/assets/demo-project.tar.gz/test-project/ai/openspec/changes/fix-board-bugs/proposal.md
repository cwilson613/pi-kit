# Fix Sprint Board Bugs

## Intent

Fix four independently-reproducible bugs in src/board.js that prevent the sprint board from functioning correctly. Each bug has been isolated to a single function and documented in the design tree.

## Scope

**In scope:**
- `getTotalCount()` — fix CSS selector to count task cards, not nested elements
- `getTasksByStatus()` — fix status comparison to use lowercase values matching stored data
- `handleAddTask()` — add event.preventDefault() to stop page reload on form submit
- `addTask()` and `updateTaskStatus()` — add saveTasks() calls to persist mutations

**Out of scope:**
- Search/filter feature (separate design node, not yet decided)
- UI redesign or new features
- Performance optimization

## Constraints

- Each bug fix must be isolated to its function — no cross-function side effects
- No new dependencies introduced
- All existing tasks (IDs 1-6) must render correctly after fixes
- localStorage must survive round-trip: add task → refresh → task still present
