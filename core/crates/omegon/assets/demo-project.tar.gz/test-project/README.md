# omegon-demo

A small Rust CLI tool that reads, validates, and displays TOML configuration files.

Used as the tutorial project for Omegon's interactive onboarding.

## Usage

```bash
cargo run -- example.toml
cargo run -- --validate example.toml
```

## Project Structure

- `src/config.rs` — TOML configuration parsing
- `src/validate.rs` — validation rules
- `src/format.rs` — output formatting
- `example.toml` — sample configuration

## Pre-Seeded Lifecycle Data

This project comes pre-seeded with Omegon lifecycle artifacts:

- **Design docs** in `docs/` — `add-validation` (decided), `output-formatting` (exploring)
- **OpenSpec change** in `openspec/changes/add-validation/` — specs + tasks ready for cleave
- **Memory facts** in `.omegon/memory/facts.jsonl` — 5 facts about the project architecture
- **Milestone** in `.omegon/milestones.json` — 0.2.0 release plan

## Customization

Fork and adapt for your team:
- Replace `src/` with your codebase
- Add design nodes in `docs/` for your architecture
- Add domain-specific memory facts to `.omegon/memory/facts.jsonl`
