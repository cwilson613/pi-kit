---
id: search-filter
title: Search and filter — task filtering UX
status: exploring
tags: [feature, ux, javascript]
open_questions:
  - Should search be fuzzy (partial match on any substring) or exact (whole word)? The current UI has no search at all — this feature is unimplemented.
---

# Search and filter — task filtering UX

## Overview

The sprint board currently has no search or filter functionality. Users with many tasks need to find specific items quickly.

## Open Questions

- Should search be fuzzy (partial match on any substring) or exact (whole word)? The current UI has no search at all — this feature is unimplemented.

## Research

*(no research yet — explore this question)*
